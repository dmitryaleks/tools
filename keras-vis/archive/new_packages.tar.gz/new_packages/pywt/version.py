
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '1.0.1'
version = '1.0.1'
full_version = '1.0.1'
git_revision = '3159423980fa033eb9c342e5d0ec2cdd0581bb12'
release = True

if not release:
    version = full_version
